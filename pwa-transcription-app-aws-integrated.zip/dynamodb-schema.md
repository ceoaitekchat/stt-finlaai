# DynamoDB Table Schema for Transcription Recordings

## Table: transcription-recordings

### Primary Key
- **recordingId** (String) - Partition Key

### Attributes
- **recordingId** (String) - Unique identifier for the recording
- **status** (String) - Current status: 'stored', 'processing', 'completed', 'error'
- **createdAt** (Number) - Timestamp when recording was created
- **updatedAt** (Number) - Timestamp when record was last updated
- **s3Key** (String) - S3 object key for the audio file
- **s3Location** (String) - Full S3 URL for the audio file
- **etag** (String) - S3 ETag for the audio file
- **originalName** (String) - Original filename of the uploaded audio
- **mimetype** (String) - MIME type of the audio file
- **size** (Number) - Size of the audio file in bytes
- **transcription** (String) - Transcribed text (when completed)
- **transcriptionService** (String) - Service used for transcription ('openai' or 'gemini')
- **transcriptionStarted** (Number) - Timestamp when transcription started
- **transcriptionCompleted** (Number) - Timestamp when transcription completed
- **error** (String) - Error message if status is 'error'

### Indexes
- **status-createdAt-index** (GSI) - Global Secondary Index
  - Partition Key: status (String)
  - Sort Key: createdAt (Number)
  - Use case: Query recordings by status, sorted by creation time

### AWS CLI Commands to Create Table

```bash
# Create the main table
aws dynamodb create-table \
    --table-name transcription-recordings \
    --attribute-definitions \
        AttributeName=recordingId,AttributeType=S \
        AttributeName=status,AttributeType=S \
        AttributeName=createdAt,AttributeType=N \
    --key-schema \
        AttributeName=recordingId,KeyType=HASH \
    --global-secondary-indexes \
        IndexName=status-createdAt-index,KeySchema=[{AttributeName=status,KeyType=HASH},{AttributeName=createdAt,KeyType=RANGE}],Projection={ProjectionType=ALL},ProvisionedThroughput={ReadCapacityUnits=5,WriteCapacityUnits=5} \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --region us-east-1

# Wait for table to be created
aws dynamodb wait table-exists --table-name transcription-recordings --region us-east-1

# Enable Point-in-Time Recovery (optional but recommended)
aws dynamodb update-continuous-backups \
    --table-name transcription-recordings \
    --point-in-time-recovery-specification PointInTimeRecoveryEnabled=true \
    --region us-east-1
```

### CloudFormation Template (Alternative)

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'DynamoDB table for PWA transcription app'

Resources:
  TranscriptionRecordingsTable:
    Type: AWS::DynamoDB::Table
    Properties:
      TableName: transcription-recordings
      AttributeDefinitions:
        - AttributeName: recordingId
          AttributeType: S
        - AttributeName: status
          AttributeType: S
        - AttributeName: createdAt
          AttributeType: N
      KeySchema:
        - AttributeName: recordingId
          KeyType: HASH
      GlobalSecondaryIndexes:
        - IndexName: status-createdAt-index
          KeySchema:
            - AttributeName: status
              KeyType: HASH
            - AttributeName: createdAt
              KeyType: RANGE
          Projection:
            ProjectionType: ALL
          ProvisionedThroughput:
            ReadCapacityUnits: 5
            WriteCapacityUnits: 5
      ProvisionedThroughput:
        ReadCapacityUnits: 5
        WriteCapacityUnits: 5
      PointInTimeRecoverySpecification:
        PointInTimeRecoveryEnabled: true
      Tags:
        - Key: Application
          Value: PWA-Transcription
        - Key: Environment
          Value: Production

Outputs:
  TableName:
    Description: 'Name of the DynamoDB table'
    Value: !Ref TranscriptionRecordingsTable
    Export:
      Name: !Sub '${AWS::StackName}-TableName'
  
  TableArn:
    Description: 'ARN of the DynamoDB table'
    Value: !GetAtt TranscriptionRecordingsTable.Arn
    Export:
      Name: !Sub '${AWS::StackName}-TableArn'
```

### Usage Examples

#### Query by Status
```javascript
// Get all completed recordings
const params = {
  TableName: 'transcription-recordings',
  IndexName: 'status-createdAt-index',
  KeyConditionExpression: '#status = :status',
  ExpressionAttributeNames: {
    '#status': 'status'
  },
  ExpressionAttributeValues: {
    ':status': 'completed'
  },
  ScanIndexForward: false // Most recent first
};

const result = await dynamodb.query(params).promise();
```

#### Get Recording by ID
```javascript
const params = {
  TableName: 'transcription-recordings',
  Key: {
    recordingId: 'your-recording-id'
  }
};

const result = await dynamodb.get(params).promise();
```

### Cost Considerations
- Provisioned capacity: 5 RCU/WCU for table and GSI
- Estimated cost: ~$3-5/month for moderate usage
- Consider switching to On-Demand billing for variable workloads
- Point-in-Time Recovery adds ~20% to storage costs

