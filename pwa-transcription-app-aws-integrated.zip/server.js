const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const { GoogleGenerativeAI } = require('@google/generative-ai');
const OpenAI = require('openai');
const AWSServices = require('./aws-services');

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize AWS services
const awsServices = new AWSServices();

// Initialize AI services
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Configure multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 25 * 1024 * 1024 // 25MB limit
  }
});

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Store recording in S3 and metadata in DynamoDB
app.post('/api/store-recording', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No audio file provided' });
    }

    const recordingId = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    
    // Upload audio to S3
    const s3Result = await awsServices.uploadAudioToS3(
      recordingId, 
      req.file.buffer, 
      req.file.mimetype
    );

    if (!s3Result.success) {
      throw new Error('Failed to upload audio to S3');
    }

    // Store metadata in DynamoDB
    const metadata = {
      originalName: req.file.originalname || 'recording.webm',
      mimetype: req.file.mimetype,
      size: req.file.size,
      s3Location: s3Result.location,
      s3Key: s3Result.key,
      etag: s3Result.etag
    };

    const dbResult = await awsServices.createRecordingRecord(recordingId, metadata);

    if (!dbResult.success) {
      // If DynamoDB fails, try to cleanup S3
      try {
        await awsServices.deleteAudioFromS3(recordingId);
      } catch (cleanupError) {
        console.error('Failed to cleanup S3 after DynamoDB error:', cleanupError);
      }
      throw new Error('Failed to store recording metadata');
    }

    res.json({ 
      recordingId, 
      message: 'Recording stored successfully in AWS',
      s3Key: s3Result.key
    });
  } catch (error) {
    console.error('Error storing recording:', error);
    res.status(500).json({ error: `Failed to store recording: ${error.message}` });
  }
});

// Transcribe with OpenAI Whisper using S3 storage
app.post('/api/transcribe/openai', async (req, res) => {
  try {
    const { recordingId } = req.body;
    
    if (!recordingId) {
      return res.status(400).json({ error: 'Recording ID is required' });
    }

    // Check if recording exists in DynamoDB
    const recordResult = await awsServices.getRecordingRecord(recordingId);
    if (!recordResult.success) {
      return res.status(404).json({ error: 'Recording not found or expired' });
    }

    // Update status to processing
    await awsServices.updateRecordingStatus(recordingId, 'processing', {
      transcriptionService: 'openai',
      transcriptionStarted: Date.now()
    });

    // Get audio from S3
    const audioResult = await awsServices.getAudioFromS3(recordingId);
    if (!audioResult.success) {
      await awsServices.updateRecordingStatus(recordingId, 'error', {
        error: 'Failed to retrieve audio from S3'
      });
      return res.status(500).json({ error: 'Failed to retrieve audio file' });
    }

    // Create a temporary file for OpenAI API
    const tempFilePath = path.join(__dirname, 'temp', `${recordingId}.webm`);
    
    // Ensure temp directory exists
    if (!fs.existsSync(path.join(__dirname, 'temp'))) {
      fs.mkdirSync(path.join(__dirname, 'temp'), { recursive: true });
    }
    
    fs.writeFileSync(tempFilePath, audioResult.buffer);

    try {
      const transcription = await openai.audio.transcriptions.create({
        file: fs.createReadStream(tempFilePath),
        model: "whisper-1",
      });

      // Update status to completed with transcription
      await awsServices.updateRecordingStatus(recordingId, 'completed', {
        transcription: transcription.text,
        transcriptionService: 'openai',
        transcriptionCompleted: Date.now()
      });

      // Clean up temp file
      fs.unlinkSync(tempFilePath);

      res.json({ 
        transcription: transcription.text,
        service: 'OpenAI Whisper',
        recordingId: recordingId
      });
    } catch (transcriptionError) {
      // Clean up temp file
      if (fs.existsSync(tempFilePath)) {
        fs.unlinkSync(tempFilePath);
      }
      
      await awsServices.updateRecordingStatus(recordingId, 'error', {
        error: `Transcription failed: ${transcriptionError.message}`,
        transcriptionService: 'openai'
      });
      
      throw transcriptionError;
    }
  } catch (error) {
    console.error('Error transcribing with OpenAI:', error);
    res.status(500).json({ error: `Failed to transcribe audio: ${error.message}` });
  }
});

// Transcribe with Google Gemini using S3 storage
app.post('/api/transcribe/gemini', async (req, res) => {
  try {
    const { recordingId } = req.body;
    
    if (!recordingId) {
      return res.status(400).json({ error: 'Recording ID is required' });
    }

    // Check if recording exists in DynamoDB
    const recordResult = await awsServices.getRecordingRecord(recordingId);
    if (!recordResult.success) {
      return res.status(404).json({ error: 'Recording not found or expired' });
    }

    // Update status to processing
    await awsServices.updateRecordingStatus(recordingId, 'processing', {
      transcriptionService: 'gemini',
      transcriptionStarted: Date.now()
    });

    // Get audio from S3
    const audioResult = await awsServices.getAudioFromS3(recordingId);
    if (!audioResult.success) {
      await awsServices.updateRecordingStatus(recordingId, 'error', {
        error: 'Failed to retrieve audio from S3'
      });
      return res.status(500).json({ error: 'Failed to retrieve audio file' });
    }

    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    const audioData = {
      inlineData: {
        data: audioResult.buffer.toString('base64'),
        mimeType: audioResult.contentType
      }
    };

    try {
      const result = await model.generateContent([
        "Please transcribe the audio content accurately. Return only the transcribed text without any additional commentary.",
        audioData
      ]);

      const response = await result.response;
      const transcription = response.text();

      // Update status to completed with transcription
      await awsServices.updateRecordingStatus(recordingId, 'completed', {
        transcription: transcription,
        transcriptionService: 'gemini',
        transcriptionCompleted: Date.now()
      });

      res.json({ 
        transcription: transcription,
        service: 'Google Gemini',
        recordingId: recordingId
      });
    } catch (transcriptionError) {
      await awsServices.updateRecordingStatus(recordingId, 'error', {
        error: `Transcription failed: ${transcriptionError.message}`,
        transcriptionService: 'gemini'
      });
      
      throw transcriptionError;
    }
  } catch (error) {
    console.error('Error transcribing with Gemini:', error);
    res.status(500).json({ error: `Failed to transcribe audio with Gemini: ${error.message}` });
  }
});

// Get recording status from DynamoDB
app.get('/api/recording/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await awsServices.getRecordingRecord(id);
    
    if (!result.success) {
      return res.json({ 
        exists: false,
        error: result.error
      });
    }

    res.json({ 
      exists: true,
      status: result.item.status,
      createdAt: result.item.createdAt,
      updatedAt: result.item.updatedAt,
      transcription: result.item.transcription || null,
      transcriptionService: result.item.transcriptionService || null,
      size: result.item.size || null
    });
  } catch (error) {
    console.error('Error getting recording status:', error);
    res.status(500).json({ error: `Failed to get recording status: ${error.message}` });
  }
});

// List all recordings (admin endpoint)
app.get('/api/recordings', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const result = await awsServices.listRecordings(limit);
    
    if (!result.success) {
      throw new Error('Failed to list recordings');
    }

    res.json({
      recordings: result.items,
      count: result.items.length
    });
  } catch (error) {
    console.error('Error listing recordings:', error);
    res.status(500).json({ error: `Failed to list recordings: ${error.message}` });
  }
});

// Delete recording (admin endpoint)
app.delete('/api/recording/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Delete from S3
    await awsServices.deleteAudioFromS3(id);
    
    // Delete from DynamoDB
    await awsServices.deleteRecordingRecord(id);
    
    res.json({ 
      success: true,
      message: 'Recording deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting recording:', error);
    res.status(500).json({ error: `Failed to delete recording: ${error.message}` });
  }
});

// Cleanup old recordings (admin endpoint)
app.post('/api/cleanup', async (req, res) => {
  try {
    const maxAgeHours = parseInt(req.body.maxAgeHours) || 24;
    const result = await awsServices.cleanupOldRecordings(maxAgeHours);
    
    res.json({
      success: true,
      message: `Cleanup completed for recordings older than ${maxAgeHours} hours`,
      results: result.cleaned
    });
  } catch (error) {
    console.error('Error during cleanup:', error);
    res.status(500).json({ error: `Cleanup failed: ${error.message}` });
  }
});

// Health check
app.get('/api/health', async (req, res) => {
  try {
    // Test AWS connectivity
    const awsHealth = {
      s3: false,
      dynamodb: false
    };

    try {
      // Test S3 connectivity
      await awsServices.s3.headBucket({ Bucket: process.env.S3_BUCKET_NAME }).promise();
      awsHealth.s3 = true;
    } catch (s3Error) {
      console.error('S3 health check failed:', s3Error.message);
    }

    try {
      // Test DynamoDB connectivity
      await awsServices.dynamodb.describe({ TableName: awsServices.tableName }).promise();
      awsHealth.dynamodb = true;
    } catch (dynamoError) {
      console.error('DynamoDB health check failed:', dynamoError.message);
    }

    res.json({ 
      status: 'OK', 
      timestamp: new Date().toISOString(),
      aws: awsHealth,
      environment: {
        hasS3Bucket: !!process.env.S3_BUCKET_NAME,
        hasDynamoTable: !!process.env.DYNAMODB_TABLE_NAME,
        hasAWSCredentials: !!(process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY)
      }
    });
  } catch (error) {
    console.error('Health check error:', error);
    res.status(500).json({ 
      status: 'ERROR',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`PWA Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`AWS Region: ${process.env.AWS_REGION || 'us-east-1'}`);
  console.log(`S3 Bucket: ${process.env.S3_BUCKET_NAME || 'NOT_CONFIGURED'}`);
  console.log(`DynamoDB Table: ${process.env.DYNAMODB_TABLE_NAME || 'transcription-recordings'}`);
});

module.exports = app;

