class TranscriptionApp {
  constructor() {
    this.mediaRecorder = null;
    this.audioChunks = [];
    this.isRecording = false;
    this.currentRecordingId = null;
    
    this.initializeElements();
    this.initializeEventListeners();
    this.registerServiceWorker();
    this.checkBrowserSupport();
  }

  initializeElements() {
    this.recordButton = document.getElementById('recordButton');
    this.recordingStatus = document.getElementById('recordingStatus');
    this.audioPreview = document.getElementById('audioPreview');
    this.openaiButton = document.getElementById('openaiButton');
    this.geminiButton = document.getElementById('geminiButton');
    this.transcriptionResult = document.getElementById('transcriptionResult');
  }

  initializeEventListeners() {
    this.recordButton.addEventListener('click', () => this.toggleRecording());
    this.openaiButton.addEventListener('click', () => this.transcribeWithService('openai'));
    this.geminiButton.addEventListener('click', () => this.transcribeWithService('gemini'));
  }

  async registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/service-worker.js');
        console.log('Service Worker registered successfully:', registration);
      } catch (error) {
        console.error('Service Worker registration failed:', error);
      }
    }
  }

  checkBrowserSupport() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      this.showError('Your browser does not support audio recording.');
      this.recordButton.disabled = true;
      return false;
    }
    return true;
  }

  async toggleRecording() {
    if (this.isRecording) {
      await this.stopRecording();
    } else {
      await this.startRecording();
    }
  }

  async startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });

      this.mediaRecorder = new MediaRecorder(stream, {
        mimeType: this.getSupportedMimeType()
      });

      this.audioChunks = [];

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.audioChunks.push(event.data);
        }
      };

      this.mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(this.audioChunks, { 
          type: this.mediaRecorder.mimeType 
        });
        
        await this.handleRecordingComplete(audioBlob);
        
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
      };

      this.mediaRecorder.start(1000); // Collect data every second
      this.isRecording = true;
      this.updateRecordingUI();

    } catch (error) {
      console.error('Error starting recording:', error);
      this.showError('Failed to start recording. Please check microphone permissions.');
    }
  }

  async stopRecording() {
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
      this.isRecording = false;
      this.updateRecordingUI();
    }
  }

  getSupportedMimeType() {
    const types = [
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/mp4',
      'audio/ogg;codecs=opus'
    ];

    for (const type of types) {
      if (MediaRecorder.isTypeSupported(type)) {
        return type;
      }
    }
    return 'audio/webm'; // fallback
  }

  async handleRecordingComplete(audioBlob) {
    try {
      // Create audio preview
      const audioUrl = URL.createObjectURL(audioBlob);
      this.audioPreview.src = audioUrl;
      this.audioPreview.style.display = 'block';

      // Store recording on server
      const formData = new FormData();
      formData.append('audio', audioBlob, 'recording.webm');

      const response = await fetch('/api/store-recording', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error('Failed to store recording');
      }

      const result = await response.json();
      this.currentRecordingId = result.recordingId;
      
      // Enable transcription buttons
      this.openaiButton.disabled = false;
      this.geminiButton.disabled = false;
      
      this.showSuccess('Recording saved! You can now transcribe it.');

    } catch (error) {
      console.error('Error handling recording:', error);
      this.showError('Failed to save recording. Please try again.');
    }
  }

  async transcribeWithService(service) {
    if (!this.currentRecordingId) {
      this.showError('No recording available. Please record audio first.');
      return;
    }

    const button = service === 'openai' ? this.openaiButton : this.geminiButton;
    const originalText = button.textContent;

    try {
      // Update UI to show loading
      button.classList.add('loading');
      button.textContent = 'Transcribing...';
      button.disabled = true;

      const response = await fetch(`/api/transcribe/${service}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          recordingId: this.currentRecordingId
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Transcription failed');
      }

      const result = await response.json();
      this.displayTranscription(result.transcription, result.service);

    } catch (error) {
      console.error('Transcription error:', error);
      this.showError(`Transcription failed: ${error.message}`);
    } finally {
      // Reset button state
      button.classList.remove('loading');
      button.textContent = originalText;
      button.disabled = false;
    }
  }

  displayTranscription(text, service) {
    this.transcriptionResult.textContent = text;
    this.transcriptionResult.classList.remove('empty');
    
    this.showSuccess(`Transcription completed using ${service}!`);
    
    // Clear the current recording ID since it's been processed
    this.currentRecordingId = null;
    this.openaiButton.disabled = true;
    this.geminiButton.disabled = true;
  }

  updateRecordingUI() {
    if (this.isRecording) {
      this.recordButton.textContent = 'Stop Recording';
      this.recordButton.classList.add('recording');
      this.recordingStatus.textContent = 'Recording... Click to stop';
      this.recordingStatus.classList.add('recording');
      
      // Disable transcription buttons during recording
      this.openaiButton.disabled = true;
      this.geminiButton.disabled = true;
    } else {
      this.recordButton.textContent = 'Start Recording';
      this.recordButton.classList.remove('recording');
      this.recordingStatus.textContent = 'Ready to record';
      this.recordingStatus.classList.remove('recording');
    }
  }

  showError(message) {
    this.removeMessages();
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    this.transcriptionResult.parentNode.appendChild(errorDiv);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.parentNode.removeChild(errorDiv);
      }
    }, 5000);
  }

  showSuccess(message) {
    this.removeMessages();
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.textContent = message;
    this.transcriptionResult.parentNode.appendChild(successDiv);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
      if (successDiv.parentNode) {
        successDiv.parentNode.removeChild(successDiv);
      }
    }, 3000);
  }

  removeMessages() {
    const messages = document.querySelectorAll('.error-message, .success-message');
    messages.forEach(msg => {
      if (msg.parentNode) {
        msg.parentNode.removeChild(msg);
      }
    });
  }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new TranscriptionApp();
});

// PWA install prompt
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
  // Prevent Chrome 67 and earlier from automatically showing the prompt
  e.preventDefault();
  // Stash the event so it can be triggered later
  deferredPrompt = e;
  
  // Show install button or banner
  showInstallPromotion();
});

function showInstallPromotion() {
  // You can show a custom install button here
  console.log('PWA install prompt available');
}

// Handle successful PWA installation
window.addEventListener('appinstalled', (evt) => {
  console.log('PWA was installed successfully');
});

// Handle online/offline status
window.addEventListener('online', () => {
  console.log('App is online');
  document.body.classList.remove('offline');
});

window.addEventListener('offline', () => {
  console.log('App is offline');
  document.body.classList.add('offline');
});

