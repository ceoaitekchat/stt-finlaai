// AWS Services Configuration
const AWS = require('aws-sdk');

class AWSServices {
  constructor() {
    // Configure AWS
    AWS.config.update({
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_REGION || 'us-east-1'
    });

    // Initialize S3
    this.s3 = new AWS.S3({
      apiVersion: '2006-03-01',
      params: {
        Bucket: process.env.S3_BUCKET_NAME
      }
    });

    // Initialize DynamoDB
    this.dynamodb = new AWS.DynamoDB.DocumentClient({
      apiVersion: '2012-08-10'
    });

    this.tableName = process.env.DYNAMODB_TABLE_NAME || 'transcription-recordings';
  }

  // S3 Methods
  async uploadAudioToS3(recordingId, audioBuffer, mimetype) {
    try {
      const key = `recordings/${recordingId}.webm`;
      
      const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
        Body: audioBuffer,
        ContentType: mimetype,
        Metadata: {
          'recording-id': recordingId,
          'upload-timestamp': Date.now().toString()
        }
      };

      const result = await this.s3.upload(params).promise();
      return {
        success: true,
        key: key,
        location: result.Location,
        etag: result.ETag
      };
    } catch (error) {
      console.error('Error uploading to S3:', error);
      throw new Error(`S3 upload failed: ${error.message}`);
    }
  }

  async getAudioFromS3(recordingId) {
    try {
      const key = `recordings/${recordingId}.webm`;
      
      const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key
      };

      const result = await this.s3.getObject(params).promise();
      return {
        success: true,
        buffer: result.Body,
        contentType: result.ContentType,
        metadata: result.Metadata
      };
    } catch (error) {
      console.error('Error getting from S3:', error);
      throw new Error(`S3 download failed: ${error.message}`);
    }
  }

  async deleteAudioFromS3(recordingId) {
    try {
      const key = `recordings/${recordingId}.webm`;
      
      const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key
      };

      await this.s3.deleteObject(params).promise();
      return { success: true };
    } catch (error) {
      console.error('Error deleting from S3:', error);
      throw new Error(`S3 deletion failed: ${error.message}`);
    }
  }

  // DynamoDB Methods
  async createRecordingRecord(recordingId, metadata = {}) {
    try {
      const timestamp = Date.now();
      
      const item = {
        recordingId: recordingId,
        status: 'stored',
        createdAt: timestamp,
        updatedAt: timestamp,
        s3Key: `recordings/${recordingId}.webm`,
        ...metadata
      };

      const params = {
        TableName: this.tableName,
        Item: item,
        ConditionExpression: 'attribute_not_exists(recordingId)'
      };

      await this.dynamodb.put(params).promise();
      return { success: true, item };
    } catch (error) {
      console.error('Error creating DynamoDB record:', error);
      throw new Error(`DynamoDB create failed: ${error.message}`);
    }
  }

  async getRecordingRecord(recordingId) {
    try {
      const params = {
        TableName: this.tableName,
        Key: {
          recordingId: recordingId
        }
      };

      const result = await this.dynamodb.get(params).promise();
      
      if (!result.Item) {
        return { success: false, error: 'Recording not found' };
      }

      return { success: true, item: result.Item };
    } catch (error) {
      console.error('Error getting DynamoDB record:', error);
      throw new Error(`DynamoDB get failed: ${error.message}`);
    }
  }

  async updateRecordingStatus(recordingId, status, additionalData = {}) {
    try {
      const timestamp = Date.now();
      
      const updateExpression = 'SET #status = :status, updatedAt = :timestamp';
      const expressionAttributeNames = { '#status': 'status' };
      const expressionAttributeValues = {
        ':status': status,
        ':timestamp': timestamp
      };

      // Add any additional data to update
      Object.keys(additionalData).forEach((key, index) => {
        const attrName = `#attr${index}`;
        const attrValue = `:val${index}`;
        updateExpression += `, ${attrName} = ${attrValue}`;
        expressionAttributeNames[attrName] = key;
        expressionAttributeValues[attrValue] = additionalData[key];
      });

      const params = {
        TableName: this.tableName,
        Key: {
          recordingId: recordingId
        },
        UpdateExpression: updateExpression,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: 'ALL_NEW'
      };

      const result = await this.dynamodb.update(params).promise();
      return { success: true, item: result.Attributes };
    } catch (error) {
      console.error('Error updating DynamoDB record:', error);
      throw new Error(`DynamoDB update failed: ${error.message}`);
    }
  }

  async deleteRecordingRecord(recordingId) {
    try {
      const params = {
        TableName: this.tableName,
        Key: {
          recordingId: recordingId
        }
      };

      await this.dynamodb.delete(params).promise();
      return { success: true };
    } catch (error) {
      console.error('Error deleting DynamoDB record:', error);
      throw new Error(`DynamoDB delete failed: ${error.message}`);
    }
  }

  async listRecordings(limit = 50) {
    try {
      const params = {
        TableName: this.tableName,
        Limit: limit,
        ScanIndexForward: false // Sort by creation time descending
      };

      const result = await this.dynamodb.scan(params).promise();
      return { success: true, items: result.Items };
    } catch (error) {
      console.error('Error listing DynamoDB records:', error);
      throw new Error(`DynamoDB scan failed: ${error.message}`);
    }
  }

  // Cleanup old recordings (can be called by a scheduled job)
  async cleanupOldRecordings(maxAgeHours = 24) {
    try {
      const cutoffTime = Date.now() - (maxAgeHours * 60 * 60 * 1000);
      
      // First, get old recordings
      const params = {
        TableName: this.tableName,
        FilterExpression: 'createdAt < :cutoff',
        ExpressionAttributeValues: {
          ':cutoff': cutoffTime
        }
      };

      const result = await this.dynamodb.scan(params).promise();
      
      // Delete from both S3 and DynamoDB
      const deletePromises = result.Items.map(async (item) => {
        try {
          // Delete from S3
          await this.deleteAudioFromS3(item.recordingId);
          // Delete from DynamoDB
          await this.deleteRecordingRecord(item.recordingId);
          return { recordingId: item.recordingId, success: true };
        } catch (error) {
          console.error(`Failed to cleanup recording ${item.recordingId}:`, error);
          return { recordingId: item.recordingId, success: false, error: error.message };
        }
      });

      const results = await Promise.all(deletePromises);
      return { success: true, cleaned: results };
    } catch (error) {
      console.error('Error during cleanup:', error);
      throw new Error(`Cleanup failed: ${error.message}`);
    }
  }
}

module.exports = AWSServices;

