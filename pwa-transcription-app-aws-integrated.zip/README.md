# PWA Transcription App with AWS Integration

A production-ready Progressive Web Application (PWA) for audio recording and transcription using AI-powered services including OpenAI Whisper and Google Gemini, with persistent AWS cloud storage.

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Architecture](#architecture)
- [AWS Integration](#aws-integration)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [AWS Setup](#aws-setup)
- [Configuration](#configuration)
- [Usage](#usage)
- [API Documentation](#api-documentation)
- [PWA Features](#pwa-features)
- [Development](#development)
- [Deployment](#deployment)
- [Security Considerations](#security-considerations)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)
- [License](#license)

## Overview

The PWA Transcription App is a modern web application that enables users to record audio directly in their browser and transcribe it using state-of-the-art AI services. Built with Node.js, Express, and vanilla JavaScript, this application provides a seamless experience across desktop and mobile devices while maintaining offline capabilities through Progressive Web App technologies.

**NEW**: This version includes full AWS integration with persistent cloud storage, replacing the previous in-memory storage system.

The application leverages two powerful AI transcription services:
- **OpenAI Whisper**: Industry-leading speech-to-text model with high accuracy across multiple languages
- **Google Gemini**: Advanced multimodal AI with audio processing capabilities

## Features

### Core Functionality
- **Real-time Audio Recording**: Browser-based audio recording using the MediaRecorder API
- **Dual AI Transcription**: Support for both OpenAI Whisper and Google Gemini transcription services
- **AWS Cloud Storage**: Persistent storage using Amazon S3 and DynamoDB
- **Progressive Web App**: Installable app with offline capabilities and native-like experience
- **Responsive Design**: Optimized for both desktop and mobile devices
- **Cross-browser Compatibility**: Works on modern browsers with MediaRecorder support

### AWS Cloud Features
- **S3 Audio Storage**: Secure, scalable storage for audio recordings
- **DynamoDB Metadata**: Fast, reliable metadata and transcription storage
- **Automatic Cleanup**: Configurable cleanup of old recordings
- **Status Tracking**: Real-time status updates for recordings and transcriptions
- **Admin Endpoints**: Management endpoints for listing and deleting recordings

### Technical Features
- **Service Worker**: Enables offline functionality and caching
- **Web App Manifest**: Provides native app-like installation experience
- **CORS Support**: Configured for cross-origin requests
- **Environment Configuration**: Secure API key management
- **Error Handling**: Comprehensive error handling and user feedback
- **Audio Format Support**: Multiple audio format support (WebM, MP4, OGG)

## Architecture

The application follows a client-server architecture with AWS cloud integration:

### Frontend (Client)
- **HTML5**: Semantic markup with PWA meta tags
- **CSS3**: Modern styling with CSS Grid, Flexbox, and custom properties
- **JavaScript (ES6+)**: Vanilla JavaScript with modern APIs
- **Service Worker**: Handles caching and offline functionality
- **Web App Manifest**: Defines PWA installation behavior

### Backend (Server)
- **Node.js**: Runtime environment
- **Express.js**: Web application framework
- **Multer**: Middleware for handling multipart/form-data
- **CORS**: Cross-Origin Resource Sharing middleware
- **AWS SDK**: Full integration with S3 and DynamoDB

### AWS Cloud Services
- **Amazon S3**: Object storage for audio files
- **Amazon DynamoDB**: NoSQL database for metadata and transcriptions
- **IAM**: Identity and Access Management for secure access

### External Services
- **OpenAI API**: Whisper model for speech-to-text transcription
- **Google Gemini API**: Multimodal AI for audio processing

## AWS Integration

### Storage Architecture

The application now uses a fully persistent AWS-based storage system:

#### Audio Storage (Amazon S3)
- **Bucket Structure**: `recordings/{recordingId}.webm`
- **Metadata**: Upload timestamp, recording ID, file size
- **Security**: Server-side encryption, access controls
- **Lifecycle**: Configurable cleanup policies

#### Metadata Storage (Amazon DynamoDB)
- **Table**: `transcription-recordings`
- **Primary Key**: `recordingId` (String)
- **Attributes**: Status, timestamps, transcription data, S3 references
- **Indexes**: Global Secondary Index on status and creation time

#### Data Flow
1. **Upload**: Audio uploaded to S3, metadata stored in DynamoDB
2. **Processing**: Status tracked in DynamoDB during transcription
3. **Completion**: Transcription results stored in DynamoDB
4. **Cleanup**: Automated cleanup of old recordings from both services

### Benefits of AWS Integration

#### Scalability
- **Horizontal Scaling**: Handle multiple concurrent users
- **Storage Scaling**: Unlimited storage capacity with S3
- **Performance**: DynamoDB provides consistent low-latency access

#### Reliability
- **Durability**: 99.999999999% (11 9's) durability with S3
- **Availability**: Multi-AZ deployment options
- **Backup**: Point-in-time recovery for DynamoDB

#### Cost Efficiency
- **Pay-as-you-go**: Only pay for storage and requests used
- **Lifecycle Policies**: Automatic cleanup reduces storage costs
- **Reserved Capacity**: Options for predictable workloads

## Prerequisites

Before installing and running the PWA Transcription App, ensure you have the following:

### System Requirements
- **Node.js**: Version 16.0 or higher
- **npm**: Version 8.0 or higher (comes with Node.js)
- **Modern Web Browser**: Chrome 66+, Firefox 60+, Safari 11.1+, or Edge 79+

### AWS Requirements
- **AWS Account**: Active AWS account with billing enabled
- **IAM User**: User with programmatic access and appropriate permissions
- **S3 Bucket**: Dedicated bucket for audio storage
- **DynamoDB Table**: Table for metadata storage

### API Keys Required
- **OpenAI API Key**: Sign up at [OpenAI Platform](https://platform.openai.com/)
- **Google Gemini API Key**: Get access through [Google AI Studio](https://makersuite.google.com/)
- **AWS Credentials**: Access Key ID and Secret Access Key

### Browser Permissions
- **Microphone Access**: Required for audio recording functionality
- **Storage Access**: For PWA installation and caching

## Installation

Follow these steps to set up the PWA Transcription App on your local machine:

### 1. Clone or Download the Project

```bash
# If using Git
git clone <repository-url>
cd pwa-transcription-app

# Or extract the downloaded ZIP file
unzip pwa-transcription-app.zip
cd pwa-transcription-app
```

### 2. Install Dependencies

```bash
npm install
```

This will install all required dependencies including:
- express
- cors
- dotenv
- multer
- @google/generative-ai
- openai
- aws-sdk

### 3. Verify Installation

```bash
npm list
```

Ensure all packages are installed without errors.

## AWS Setup

### 1. Create AWS Resources

#### S3 Bucket Creation

```bash
# Using AWS CLI
aws s3 mb s3://your-transcription-app-bucket --region us-east-1

# Enable versioning (optional but recommended)
aws s3api put-bucket-versioning \
    --bucket your-transcription-app-bucket \
    --versioning-configuration Status=Enabled

# Set up lifecycle policy for cleanup
aws s3api put-bucket-lifecycle-configuration \
    --bucket your-transcription-app-bucket \
    --lifecycle-configuration file://lifecycle-policy.json
```

#### DynamoDB Table Creation

```bash
# Create the main table
aws dynamodb create-table \
    --table-name transcription-recordings \
    --attribute-definitions \
        AttributeName=recordingId,AttributeType=S \
        AttributeName=status,AttributeType=S \
        AttributeName=createdAt,AttributeType=N \
    --key-schema \
        AttributeName=recordingId,KeyType=HASH \
    --global-secondary-indexes \
        IndexName=status-createdAt-index,KeySchema=[{AttributeName=status,KeyType=HASH},{AttributeName=createdAt,KeyType=RANGE}],Projection={ProjectionType=ALL},ProvisionedThroughput={ReadCapacityUnits=5,WriteCapacityUnits=5} \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --region us-east-1

# Wait for table to be created
aws dynamodb wait table-exists --table-name transcription-recordings --region us-east-1
```

### 2. IAM Permissions

Create an IAM policy with the following permissions:

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject",
                "s3:HeadObject"
            ],
            "Resource": "arn:aws:s3:::your-transcription-app-bucket/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket",
                "s3:HeadBucket"
            ],
            "Resource": "arn:aws:s3:::your-transcription-app-bucket"
        },
        {
            "Effect": "Allow",
            "Action": [
                "dynamodb:GetItem",
                "dynamodb:PutItem",
                "dynamodb:UpdateItem",
                "dynamodb:DeleteItem",
                "dynamodb:Query",
                "dynamodb:Scan"
            ],
            "Resource": [
                "arn:aws:dynamodb:us-east-1:*:table/transcription-recordings",
                "arn:aws:dynamodb:us-east-1:*:table/transcription-recordings/index/*"
            ]
        }
    ]
}
```

### 3. CloudFormation Template (Alternative)

For automated setup, use the provided CloudFormation template:

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'AWS resources for PWA transcription app'

Parameters:
  BucketName:
    Type: String
    Default: transcription-app-bucket
    Description: Name for the S3 bucket

Resources:
  S3Bucket:
    Type: AWS::S3::Bucket
    Properties:
      BucketName: !Ref BucketName
      VersioningConfiguration:
        Status: Enabled
      LifecycleConfiguration:
        Rules:
          - Id: DeleteOldRecordings
            Status: Enabled
            ExpirationInDays: 30

  DynamoDBTable:
    Type: AWS::DynamoDB::Table
    Properties:
      TableName: transcription-recordings
      AttributeDefinitions:
        - AttributeName: recordingId
          AttributeType: S
        - AttributeName: status
          AttributeType: S
        - AttributeName: createdAt
          AttributeType: N
      KeySchema:
        - AttributeName: recordingId
          KeyType: HASH
      GlobalSecondaryIndexes:
        - IndexName: status-createdAt-index
          KeySchema:
            - AttributeName: status
              KeyType: HASH
            - AttributeName: createdAt
              KeyType: RANGE
          Projection:
            ProjectionType: ALL
          ProvisionedThroughput:
            ReadCapacityUnits: 5
            WriteCapacityUnits: 5
      ProvisionedThroughput:
        ReadCapacityUnits: 5
        WriteCapacityUnits: 5

Outputs:
  BucketName:
    Description: 'S3 Bucket Name'
    Value: !Ref S3Bucket
  TableName:
    Description: 'DynamoDB Table Name'
    Value: !Ref DynamoDBTable
```

Deploy with:
```bash
aws cloudformation create-stack \
    --stack-name transcription-app-stack \
    --template-body file://cloudformation-template.yaml \
    --parameters ParameterKey=BucketName,ParameterValue=your-unique-bucket-name
```

## Configuration

### Environment Variables

The application uses environment variables for secure configuration. Update the `.env` file in the project root:

### Required Environment Variables

```env
# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key_here

# Google Gemini Configuration  
GEMINI_API_KEY=your_gemini_api_key_here

# AWS Configuration (REQUIRED)
AWS_ACCESS_KEY_ID=your_aws_access_key_id
AWS_SECRET_ACCESS_KEY=your_aws_secret_access_key
AWS_REGION=us-east-1
S3_BUCKET_NAME=your-transcription-app-bucket
DYNAMODB_TABLE_NAME=transcription-recordings

# Server Configuration (Optional)
PORT=3000
NODE_ENV=production
```

### Obtaining Credentials

#### AWS Credentials
1. Log in to [AWS Console](https://aws.amazon.com/console/)
2. Navigate to IAM (Identity and Access Management)
3. Create a new user with programmatic access
4. Attach the policy created in the AWS Setup section
5. Copy the Access Key ID and Secret Access Key
6. Set the region to match your S3 bucket and DynamoDB table

#### OpenAI API Key
1. Visit [OpenAI Platform](https://platform.openai.com/)
2. Sign up or log in to your account
3. Navigate to API Keys section
4. Create a new API key
5. Copy the key and add it to your `.env` file

#### Google Gemini API Key
1. Go to [Google AI Studio](https://makersuite.google.com/)
2. Sign in with your Google account
3. Create a new project or select an existing one
4. Generate an API key
5. Copy the key and add it to your `.env` file

### Security Best Practices

- **Never commit `.env` files** to version control
- **Use environment-specific configurations** for different deployment environments
- **Regularly rotate API keys** for security
- **Monitor API usage** to prevent unexpected charges
- **Use least privilege principle** for AWS IAM policies
- **Enable AWS CloudTrail** for audit logging
- **Set up billing alerts** for cost monitoring

## Usage

### Starting the Application

#### Development Mode
```bash
npm run dev
```

#### Production Mode
```bash
npm start
```

The application will start on `http://localhost:3000` (or the port specified in your `.env` file).

### Using the Application

#### 1. Recording Audio
1. Open the application in your web browser
2. Grant microphone permissions when prompted
3. Click the "Start Recording" button
4. Speak clearly into your microphone
5. Click "Stop Recording" when finished
6. The audio will be automatically uploaded to AWS S3

#### 2. Transcribing Audio
1. After recording, choose your preferred transcription service:
   - **OpenAI Whisper**: Click "Transcribe with OpenAI"
   - **Google Gemini**: Click "Transcribe with Gemini"
2. The system will fetch the audio from S3 and process it
3. Status updates are tracked in DynamoDB
4. The transcribed text will appear in the results area
5. Transcription results are permanently stored in DynamoDB

#### 3. Managing Recordings
- **View Status**: Check recording and transcription status
- **List Recordings**: Admin endpoint to view all recordings
- **Delete Recordings**: Remove recordings from both S3 and DynamoDB
- **Automatic Cleanup**: Configure automatic cleanup of old recordings

## API Documentation

The application provides comprehensive REST API endpoints for audio processing and transcription with AWS integration.

### Base URL
```
http://localhost:3000/api
```

### Endpoints

#### Store Recording
**POST** `/api/store-recording`

Stores an audio recording in AWS S3 and metadata in DynamoDB.

**Request:**
- Method: POST
- Content-Type: multipart/form-data
- Body: Audio file (form field: 'audio')

**Response:**
```json
{
  "recordingId": "1640995200000abc123",
  "message": "Recording stored successfully in AWS",
  "s3Key": "recordings/1640995200000abc123.webm"
}
```

#### Transcribe with OpenAI
**POST** `/api/transcribe/openai`

Transcribes audio using OpenAI Whisper model, fetching from S3.

**Request:**
```json
{
  "recordingId": "1640995200000abc123"
}
```

**Response:**
```json
{
  "transcription": "Hello, this is a test transcription.",
  "service": "OpenAI Whisper",
  "recordingId": "1640995200000abc123"
}
```

#### Transcribe with Gemini
**POST** `/api/transcribe/gemini`

Transcribes audio using Google Gemini model, fetching from S3.

**Request:**
```json
{
  "recordingId": "1640995200000abc123"
}
```

**Response:**
```json
{
  "transcription": "Hello, this is a test transcription.",
  "service": "Google Gemini",
  "recordingId": "1640995200000abc123"
}
```

#### Recording Status
**GET** `/api/recording/:id/status`

Gets recording status and metadata from DynamoDB.

**Response:**
```json
{
  "exists": true,
  "status": "completed",
  "createdAt": 1640995200000,
  "updatedAt": 1640995260000,
  "transcription": "Hello, this is a test transcription.",
  "transcriptionService": "openai",
  "size": 245760
}
```

#### List Recordings (Admin)
**GET** `/api/recordings?limit=50`

Lists all recordings with metadata.

**Response:**
```json
{
  "recordings": [
    {
      "recordingId": "1640995200000abc123",
      "status": "completed",
      "createdAt": 1640995200000,
      "transcription": "Hello, this is a test transcription.",
      "size": 245760
    }
  ],
  "count": 1
}
```

#### Delete Recording (Admin)
**DELETE** `/api/recording/:id`

Deletes recording from both S3 and DynamoDB.

**Response:**
```json
{
  "success": true,
  "message": "Recording deleted successfully"
}
```

#### Cleanup Old Recordings (Admin)
**POST** `/api/cleanup`

Removes recordings older than specified hours.

**Request:**
```json
{
  "maxAgeHours": 24
}
```

**Response:**
```json
{
  "success": true,
  "message": "Cleanup completed for recordings older than 24 hours",
  "results": [
    {
      "recordingId": "old-recording-id",
      "success": true
    }
  ]
}
```

#### Health Check
**GET** `/api/health`

Returns server health status and AWS connectivity.

**Response:**
```json
{
  "status": "OK",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "aws": {
    "s3": true,
    "dynamodb": true
  },
  "environment": {
    "hasS3Bucket": true,
    "hasDynamoTable": true,
    "hasAWSCredentials": true
  }
}
```

### Error Responses

All endpoints return appropriate HTTP status codes and error messages:

```json
{
  "error": "Error description"
}
```

Common error codes:
- **400**: Bad Request (missing parameters, invalid data)
- **404**: Not Found (recording not found)
- **500**: Internal Server Error (AWS failures, API issues)

## Deployment

### Production Deployment with AWS

#### 1. Environment Configuration

Create production `.env` file:
```env
NODE_ENV=production
PORT=3000
OPENAI_API_KEY=your_production_openai_key
GEMINI_API_KEY=your_production_gemini_key
AWS_ACCESS_KEY_ID=your_production_aws_key
AWS_SECRET_ACCESS_KEY=your_production_aws_secret
AWS_REGION=us-east-1
S3_BUCKET_NAME=your-production-bucket
DYNAMODB_TABLE_NAME=transcription-recordings
```

#### 2. AWS Production Setup

##### S3 Production Configuration
```bash
# Create production bucket with encryption
aws s3api create-bucket \
    --bucket your-production-transcription-bucket \
    --region us-east-1

# Enable server-side encryption
aws s3api put-bucket-encryption \
    --bucket your-production-transcription-bucket \
    --server-side-encryption-configuration '{
        "Rules": [
            {
                "ApplyServerSideEncryptionByDefault": {
                    "SSEAlgorithm": "AES256"
                }
            }
        ]
    }'

# Set up CORS for web access
aws s3api put-bucket-cors \
    --bucket your-production-transcription-bucket \
    --cors-configuration file://cors-config.json
```

##### DynamoDB Production Configuration
```bash
# Create production table with backup
aws dynamodb create-table \
    --table-name transcription-recordings-prod \
    --attribute-definitions \
        AttributeName=recordingId,AttributeType=S \
        AttributeName=status,AttributeType=S \
        AttributeName=createdAt,AttributeType=N \
    --key-schema \
        AttributeName=recordingId,KeyType=HASH \
    --global-secondary-indexes \
        IndexName=status-createdAt-index,KeySchema=[{AttributeName=status,KeyType=HASH},{AttributeName=createdAt,KeyType=RANGE}],Projection={ProjectionType=ALL},ProvisionedThroughput={ReadCapacityUnits=10,WriteCapacityUnits=10} \
    --provisioned-throughput \
        ReadCapacityUnits=10,WriteCapacityUnits=10 \
    --region us-east-1

# Enable point-in-time recovery
aws dynamodb update-continuous-backups \
    --table-name transcription-recordings-prod \
    --point-in-time-recovery-specification PointInTimeRecoveryEnabled=true
```

#### 3. Application Deployment

##### Using PM2 (Recommended)
```bash
# Install PM2 globally
npm install -g pm2

# Create ecosystem file
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'transcription-app',
    script: 'server.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
};
EOF

# Start application
pm2 start ecosystem.config.js --env production

# Save PM2 configuration
pm2 save
pm2 startup
```

##### Using Docker
```dockerfile
FROM node:16-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 3000

USER node

CMD ["node", "server.js"]
```

```bash
# Build and run
docker build -t transcription-app .
docker run -d -p 3000:3000 --env-file .env transcription-app
```

#### 4. Load Balancer and SSL

##### Using AWS Application Load Balancer
```bash
# Create target group
aws elbv2 create-target-group \
    --name transcription-app-targets \
    --protocol HTTP \
    --port 3000 \
    --vpc-id vpc-12345678 \
    --health-check-path /api/health

# Create load balancer
aws elbv2 create-load-balancer \
    --name transcription-app-lb \
    --subnets subnet-12345678 subnet-87654321 \
    --security-groups sg-12345678
```

##### SSL Certificate with ACM
```bash
# Request certificate
aws acm request-certificate \
    --domain-name transcription.yourdomain.com \
    --validation-method DNS
```

### Monitoring and Logging

#### CloudWatch Integration
```javascript
// Add to server.js
const AWS = require('aws-sdk');
const cloudwatch = new AWS.CloudWatch();

// Custom metrics
const putMetric = (metricName, value, unit = 'Count') => {
  const params = {
    Namespace: 'TranscriptionApp',
    MetricData: [{
      MetricName: metricName,
      Value: value,
      Unit: unit,
      Timestamp: new Date()
    }]
  };
  
  cloudwatch.putMetricData(params).promise()
    .catch(err => console.error('CloudWatch error:', err));
};

// Usage in endpoints
app.post('/api/transcribe/openai', async (req, res) => {
  try {
    // ... transcription logic
    putMetric('TranscriptionSuccess', 1);
    putMetric('TranscriptionLatency', processingTime, 'Milliseconds');
  } catch (error) {
    putMetric('TranscriptionError', 1);
    throw error;
  }
});
```

#### Log Aggregation
```bash
# Install Winston for structured logging
npm install winston winston-cloudwatch

# Configure in server.js
const winston = require('winston');
const WinstonCloudWatch = require('winston-cloudwatch');

const logger = winston.createLogger({
  transports: [
    new winston.transports.Console(),
    new WinstonCloudWatch({
      logGroupName: 'transcription-app',
      logStreamName: 'application-logs',
      awsRegion: process.env.AWS_REGION
    })
  ]
});
```

### Cost Optimization

#### S3 Cost Management
- **Lifecycle Policies**: Automatically delete old recordings
- **Storage Classes**: Use IA or Glacier for long-term storage
- **Compression**: Compress audio files before upload

#### DynamoDB Cost Management
- **On-Demand Billing**: For variable workloads
- **Reserved Capacity**: For predictable usage
- **TTL**: Automatic item expiration

#### Monitoring Costs
```bash
# Set up billing alerts
aws budgets create-budget \
    --account-id 123456789012 \
    --budget '{
        "BudgetName": "TranscriptionAppBudget",
        "BudgetLimit": {
            "Amount": "50.0",
            "Unit": "USD"
        },
        "TimeUnit": "MONTHLY",
        "BudgetType": "COST"
    }'
```

## Security Considerations

### AWS Security Best Practices

#### IAM Security
- **Least Privilege**: Grant minimum required permissions
- **Role-Based Access**: Use IAM roles instead of users when possible
- **MFA**: Enable multi-factor authentication
- **Access Keys Rotation**: Regularly rotate access keys

#### S3 Security
- **Bucket Policies**: Restrict access to specific IP ranges or VPCs
- **Encryption**: Enable server-side encryption
- **Versioning**: Enable versioning for data protection
- **Access Logging**: Enable access logging for audit trails

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "RestrictToApplication",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::ACCOUNT:user/transcription-app-user"
            },
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject"
            ],
            "Resource": "arn:aws:s3:::your-bucket/*",
            "Condition": {
                "StringEquals": {
                    "s3:x-amz-server-side-encryption": "AES256"
                }
            }
        }
    ]
}
```

#### DynamoDB Security
- **Encryption at Rest**: Enable encryption for sensitive data
- **VPC Endpoints**: Use VPC endpoints for private access
- **Fine-grained Access**: Use condition expressions for access control

#### Application Security
- **Input Validation**: Validate all user inputs
- **Rate Limiting**: Implement rate limiting to prevent abuse
- **HTTPS Only**: Force HTTPS in production
- **Security Headers**: Implement security headers

```javascript
// Security middleware
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://api.openai.com", "https://generativelanguage.googleapis.com"]
    }
  }
}));

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP'
});

app.use('/api/', limiter);
```

### Data Privacy

#### GDPR Compliance
- **Data Minimization**: Only collect necessary data
- **Right to Deletion**: Implement data deletion endpoints
- **Data Portability**: Provide data export functionality
- **Consent Management**: Implement proper consent mechanisms

#### Audio Data Handling
- **Temporary Processing**: Delete temporary files immediately
- **Encryption in Transit**: Use HTTPS for all communications
- **Access Logging**: Log all access to audio data
- **Retention Policies**: Implement automatic data deletion

## Troubleshooting

### Common AWS Issues

#### S3 Connection Problems
```bash
# Test S3 connectivity
aws s3 ls s3://your-bucket-name --region us-east-1

# Check bucket permissions
aws s3api get-bucket-policy --bucket your-bucket-name

# Verify credentials
aws sts get-caller-identity
```

#### DynamoDB Issues
```bash
# Check table status
aws dynamodb describe-table --table-name transcription-recordings

# Test read/write permissions
aws dynamodb put-item \
    --table-name transcription-recordings \
    --item '{"recordingId": {"S": "test"}, "status": {"S": "test"}}'

aws dynamodb delete-item \
    --table-name transcription-recordings \
    --key '{"recordingId": {"S": "test"}}'
```

#### IAM Permission Issues
```bash
# Simulate policy
aws iam simulate-principal-policy \
    --policy-source-arn arn:aws:iam::ACCOUNT:user/transcription-app-user \
    --action-names s3:GetObject \
    --resource-arns arn:aws:s3:::your-bucket/*
```

### Application Debugging

#### Enable Debug Logging
```javascript
// Add to server.js
const debug = require('debug')('transcription-app');

// Use throughout application
debug('Processing recording:', recordingId);
debug('S3 upload result:', s3Result);
debug('DynamoDB operation:', operation);
```

#### Health Check Endpoint
The `/api/health` endpoint provides comprehensive status information:
- AWS service connectivity
- Environment configuration
- Service availability

#### Error Monitoring
```javascript
// Add error tracking
const Sentry = require('@sentry/node');

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV
});

app.use(Sentry.Handlers.errorHandler());
```

### Performance Issues

#### S3 Upload Optimization
```javascript
// Use multipart upload for large files
const uploadParams = {
  Bucket: bucketName,
  Key: key,
  Body: buffer,
  ContentType: mimetype,
  StorageClass: 'STANDARD_IA' // For infrequent access
};

// Add progress tracking
const upload = s3.upload(uploadParams);
upload.on('httpUploadProgress', (progress) => {
  console.log(`Upload progress: ${progress.loaded}/${progress.total}`);
});
```

#### DynamoDB Performance
```javascript
// Use batch operations for multiple items
const batchParams = {
  RequestItems: {
    'transcription-recordings': [
      {
        PutRequest: {
          Item: item1
        }
      },
      {
        PutRequest: {
          Item: item2
        }
      }
    ]
  }
};

await dynamodb.batchWrite(batchParams).promise();
```

## Contributing

We welcome contributions to improve the PWA Transcription App! Please follow these guidelines:

### Development Setup
1. Fork the repository
2. Create a feature branch
3. Set up AWS resources for testing
4. Make your changes
5. Test thoroughly
6. Submit a pull request

### Code Standards
- Use ESLint for code linting
- Follow existing code style
- Add tests for new features
- Update documentation

### Testing
- Test all AWS integrations
- Verify PWA functionality
- Test across different browsers
- Include error scenarios

## License

This project is licensed under the MIT License. See the LICENSE file for details.

---

## Quick Start Checklist

- [ ] Install Node.js and npm
- [ ] Clone/download the project
- [ ] Run `npm install`
- [ ] Set up AWS S3 bucket
- [ ] Create DynamoDB table
- [ ] Configure IAM permissions
- [ ] Get OpenAI API key
- [ ] Get Google Gemini API key
- [ ] Update `.env` file with all credentials
- [ ] Run `npm start`
- [ ] Test recording and transcription
- [ ] Install as PWA

For detailed instructions, refer to the sections above.

