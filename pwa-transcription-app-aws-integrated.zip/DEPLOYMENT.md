# Deployment Guide for PWA Transcription App with AWS

## Quick Deployment Checklist

### 1. AWS Resources Setup
```bash
# Create S3 bucket
aws s3 mb s3://your-transcription-app-bucket --region us-east-1

# Create DynamoDB table
aws dynamodb create-table \
    --table-name transcription-recordings \
    --attribute-definitions \
        AttributeName=recordingId,AttributeType=S \
        AttributeName=status,AttributeType=S \
        AttributeName=createdAt,AttributeType=N \
    --key-schema \
        AttributeName=recordingId,KeyType=HASH \
    --global-secondary-indexes \
        IndexName=status-createdAt-index,KeySchema=[{AttributeName=status,KeyType=HASH},{AttributeName=createdAt,KeyType=RANGE}],Projection={ProjectionType=ALL},ProvisionedThroughput={ReadCapacityUnits=5,WriteCapacityUnits=5} \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --region us-east-1
```

### 2. Environment Configuration
Copy `.env.example` to `.env` and fill in your credentials:
```env
OPENAI_API_KEY=your_openai_api_key
GEMINI_API_KEY=your_gemini_api_key
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_REGION=us-east-1
S3_BUCKET_NAME=your-transcription-app-bucket
DYNAMODB_TABLE_NAME=transcription-recordings
```

### 3. Application Deployment
```bash
# Install dependencies
npm install

# Test locally
npm start

# Deploy with PM2 (production)
npm install -g pm2
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup
```

### 4. Health Check
Visit `http://your-domain/api/health` to verify:
- AWS S3 connectivity
- DynamoDB connectivity
- Environment configuration

## Cost Estimates

### AWS Services (Monthly)
- **S3 Storage**: ~$0.023 per GB stored
- **S3 Requests**: ~$0.0004 per 1,000 requests
- **DynamoDB**: ~$1.25 per month (5 RCU/WCU)
- **Data Transfer**: ~$0.09 per GB out

**Estimated Total**: $5-15/month for moderate usage

### Optimization Tips
1. Enable S3 lifecycle policies for automatic cleanup
2. Use DynamoDB on-demand billing for variable workloads
3. Implement CloudWatch monitoring for cost tracking
4. Set up billing alerts

## Security Checklist

- [ ] IAM user with minimal permissions
- [ ] S3 bucket encryption enabled
- [ ] DynamoDB encryption at rest
- [ ] HTTPS enforced in production
- [ ] Rate limiting configured
- [ ] Security headers implemented
- [ ] API keys secured in environment variables
- [ ] CloudTrail logging enabled

## Monitoring Setup

### CloudWatch Alarms
```bash
# High error rate alarm
aws cloudwatch put-metric-alarm \
    --alarm-name "TranscriptionApp-HighErrorRate" \
    --alarm-description "High error rate in transcription app" \
    --metric-name "TranscriptionError" \
    --namespace "TranscriptionApp" \
    --statistic Sum \
    --period 300 \
    --threshold 10 \
    --comparison-operator GreaterThanThreshold

# High DynamoDB consumption
aws cloudwatch put-metric-alarm \
    --alarm-name "DynamoDB-HighConsumption" \
    --alarm-description "High DynamoDB read/write consumption" \
    --metric-name "ConsumedReadCapacityUnits" \
    --namespace "AWS/DynamoDB" \
    --dimensions Name=TableName,Value=transcription-recordings \
    --statistic Sum \
    --period 300 \
    --threshold 80 \
    --comparison-operator GreaterThanThreshold
```

### Log Aggregation
Consider setting up:
- CloudWatch Logs for application logs
- AWS X-Ray for distributed tracing
- Third-party monitoring (DataDog, New Relic)

## Backup Strategy

### DynamoDB Backups
```bash
# Enable point-in-time recovery
aws dynamodb update-continuous-backups \
    --table-name transcription-recordings \
    --point-in-time-recovery-specification PointInTimeRecoveryEnabled=true

# Create on-demand backup
aws dynamodb create-backup \
    --table-name transcription-recordings \
    --backup-name transcription-recordings-backup-$(date +%Y%m%d)
```

### S3 Versioning
```bash
# Enable versioning
aws s3api put-bucket-versioning \
    --bucket your-transcription-app-bucket \
    --versioning-configuration Status=Enabled

# Set up cross-region replication (optional)
aws s3api put-bucket-replication \
    --bucket your-transcription-app-bucket \
    --replication-configuration file://replication-config.json
```

## Troubleshooting

### Common Issues

1. **S3 Access Denied**
   - Check IAM permissions
   - Verify bucket policy
   - Ensure correct region

2. **DynamoDB Throttling**
   - Increase provisioned capacity
   - Switch to on-demand billing
   - Implement exponential backoff

3. **High Latency**
   - Check AWS region proximity
   - Optimize DynamoDB queries
   - Implement caching

4. **Memory Issues**
   - Monitor Node.js memory usage
   - Implement streaming for large files
   - Add memory limits to PM2

### Debug Commands
```bash
# Check AWS credentials
aws sts get-caller-identity

# Test S3 access
aws s3 ls s3://your-bucket-name

# Check DynamoDB table
aws dynamodb describe-table --table-name transcription-recordings

# View application logs
pm2 logs transcription-app

# Monitor system resources
pm2 monit
```

## Scaling Considerations

### Horizontal Scaling
- Use Application Load Balancer
- Deploy multiple instances
- Implement session affinity if needed

### Database Scaling
- DynamoDB auto-scaling
- Read replicas for read-heavy workloads
- Global tables for multi-region

### Storage Scaling
- S3 automatically scales
- Consider CloudFront for global distribution
- Implement intelligent tiering

## Maintenance

### Regular Tasks
- Monitor AWS costs
- Review CloudWatch metrics
- Update dependencies
- Rotate API keys
- Clean up old recordings
- Review security logs

### Automated Maintenance
```bash
# Set up automated cleanup (cron job)
0 2 * * * curl -X POST http://localhost:3000/api/cleanup -H "Content-Type: application/json" -d '{"maxAgeHours": 168}'

# Automated backups
0 3 * * 0 aws dynamodb create-backup --table-name transcription-recordings --backup-name weekly-backup-$(date +%Y%m%d)
```

